const express = require('express');
const controller = require('../controllers/tradeController');
const { isLoggedIn, isOwner } = require('../middlewares/auth');
const { validateId, validateTrade, validateResult } = require('../middlewares/validator');

const router = express.Router();

//GET /trades: send all trades to the user

router.get('/', controller.index);

//GET /trades/new: send html form to create new trade

router.get('/new', isLoggedIn, controller.new);

//POST /trades: create a new trade

router.post('/', isLoggedIn, validateTrade, validateResult, controller.create);


//GET /trades/:id: send details of the trade identified by id

router.get('/:id', validateId, controller.show);


//GET /trades/:id/edit: send html form for editing existing trade

router.get('/:id/edit', validateId, isLoggedIn, isOwner, controller.edit);


//PUT /trades/:id: update the trade identified by id

router.put('/:id', validateId, isLoggedIn, isOwner, validateTrade, validateResult, controller.update);


//DELETE /trades/:id: delete the trade identified by id

router.delete('/:id', validateId, isLoggedIn, isOwner, controller.delete);


module.exports = router;
