const express = require('express');
const controller = require('../controllers/mainController');

const router = express.Router();


// GET /: send landing page to user
router.get('/', controller.index);

// GET /about: send about page to user
router.get('/about', controller.about);

// GET /contact: send contact page to user
router.get('/contact', controller.contact);


module.exports = router;
