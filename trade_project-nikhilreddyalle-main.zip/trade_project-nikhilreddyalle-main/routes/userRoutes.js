const express = require('express');
const controller = require('../controllers/userController');
const { isGuest, isLoggedIn, isAvailableTrade } = require('../middlewares/auth');
const { validateSignUp, validateResult, validateLogin, validateId } = require('../middlewares/validator');
const { logInLimiter } = require('../middlewares/rateLimiters');


const router = express.Router();

//GET /users/new: send html form for creating a new user account

router.get('/new', isGuest, controller.new);

//POST /users: create a new user account

router.post('/', isGuest, validateSignUp, validateResult, controller.create);

//GET /users/login: send html for logging in
router.get('/login', isGuest, controller.getUserLogin);

//POST /users/login: authenticate user's login
router.post('/login', logInLimiter, isGuest, validateLogin, validateResult, controller.login);

//GET /users/profile: send user's profile page
router.get('/profile', isLoggedIn, controller.profile);

//POST /users/logout: logout a user
router.get('/logout', isLoggedIn, controller.logout);

//PUT /users/trade/:id/watch: add or remove the trade from wishlist
router.put('/trade/:id/watch', validateId, isLoggedIn, controller.addOrRemoveWishlistItem);

//GET /users/trade/:id/ show Available Trades for trading
router.get('/trade/:id/', validateId, isLoggedIn, isAvailableTrade, controller.showOfferableTrades);

//POST /users/trade/:id/ add trade offer
router.post('/trade/:id/', validateId, isLoggedIn, isAvailableTrade, controller.addOffer);

//DELETE /users/trade/offer/:id/ cancel trade offer
router.delete('/trade/offer/:id/', validateId, isLoggedIn, controller.deleteOffer)

//PUT /users/trade/offer/:id/ cancel trade offer
router.put('/trade/offer/:id/', validateId, isLoggedIn, controller.acceptOffer)


module.exports = router;
