const Trade = require('../models/trade')

// check if user is a guest
exports.isGuest = (req, res, next) => {
    if(!req.session.user)
        return next();
    else{
        req.flash('error', 'You are logged in already');
        return res.redirect('/users/profile');
    }
};

// check if user is a authenticated
exports.isLoggedIn = (req, res, next) => {
    if(req.session.user)
        return next();
    else{
        req.flash('error', 'You need to log in first');
        return res.redirect('/users/login');
    }
};

// check if user is owner of the trade
exports.isOwner = (req, res, next) => {
    let id = req.params.id;
    Trade.findById(id)
    .then(trade => {
        if(trade) {
            if(trade.owner == req.session.user){
                console.log("is owner");
                return next();
            } else {
                let err = new Error('Unauthorized to access the resource');
                err.status = 401;
                return next(err);
            }
        } else {
            let err = new Error('Cannot find a connection with id ' + req.params.id);
            err.status = 404;
            return next(err);
        }
    })
    .catch(err => next(err));
};

exports.isAvailableTrade = (req, res, next) => {
    let id = req.params.id;
    Trade.findById(id)
    .then(trade => {
        if(trade){
            if(trade.status === "Available"){
                return next();
            } else {
                let err = new Error('The Trade Status is not Available');
                err.status = 400;
                return next(err);
            }
        } else {
            let err = new Error('Cannot find a trade with id ' + req.params.id);
            err.status = 404;
            return next(err);
        }
    })
    .catch(err => next(err));
}
