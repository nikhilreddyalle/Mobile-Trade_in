const model = require("../models/trade");
const User = require("../models/user");

function handle404Error(id, next) {
    let err = new Error(`Cannot find the trade with id ${id}`);
    err.status = 404;
    next(err);
}

function handleValidationError(err, next) {
    if(err.name = 'ValidationError'){
        req.flash('error', err.message);
        err.status = 400;
    }
    next(err);
}

exports.index = (req, res, next) => {
    model.find().sort('name')
    .then(trades => {
        model.distinct('category')
        .then(categories => {
            categories.sort();
            res.render('./trade/index', {trades, categories});
        })
    })
    .catch(err => next(err));
};

exports.new = (req, res) => {
    res.render('./trade/new');
};

exports.create = (req, res) => {
    let trade = new model(req.body);
    trade.owner = req.session.user;
    trade.save()
    .then(trade => {
        req.flash('success', 'Trade has been created successfully');
        res.redirect('/trades')
    })
    .catch(err => handleValidationError(err, next));
};


exports.show = (req, res, next) => {
    let id = req.params.id;
    let user = req.session.user;
    model.findById(id).populate('owner', 'firstName lastName')
        .then(trade => {
            if (trade) {
                User.findById(user)
                    .then(user => {
                        isWishlished = false;
                        if (user) {
                            isWishlished = user.wishlist.includes(id);
                        }
                        return res.render('./trade/show', {
                            trade,
                            isWishlished
                        });
                    })
            } else {
                handle404Error(id, next);
            }
        })
        .catch(err => next(err));
};


exports.edit = (req, res, next) => {
    let id = req.params.id;
    model.findById(id)
    .then(trade => {
        return res.render('./trade/edit', {trade});
    })
    .catch(err => next(err));
};


exports.update = (req, res, next) => {
    let id = req.params.id;
    let trade = req.body;
    model.findByIdAndUpdate(id, trade, {useFindAndModify: false, runValidators: true})
    .then(trade => {
        return res.redirect(`/trades/${id}`);
    })
    .catch(err => handleValidationError(err, next));
};


exports.delete = (req, res, next) => {
    let id = req.params.id;
    let usera = req.session.user;
    console.log("got id "+id+" and "+usera)

    model.findByIdAndDelete(id, function (err, docs) {
        if (err){
            console.log(err)
        }
        else{
            console.log("Deleted : ", docs);
        }
    }).then(a=>     res.redirect('/trades')

    )



};
