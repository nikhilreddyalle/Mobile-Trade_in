const model = require('../models/user');
const Trade = require('../models/trade');

function handle404Error(id, next) {
    let err = new Error(`Cannot find the trade with id ${id}`);
    err.status = 404;
    next(err);
}

exports.new = (req, res) => {
    res.render('./user/new');
};

exports.create = (req, res, next) => {
    let user = new model(req.body);
    user.save() //insert the document to the database
        .then(user => {
            req.flash('success', 'Registration succeeded!');
            res.redirect('/users/login')
        })
        .catch(err => {
            if (err.name === 'ValidationError') {
                req.flash('error', err.message);
                return res.redirect('back');
            }

            if (err.code === 11000) {
                req.flash('error', 'Email has been used');
                return res.redirect('back');
            }

            next(err);
        });
};

exports.getUserLogin = (req, res, next) => {

    res.render('./user/login');
}

exports.login = (req, res, next) => {

    let email = req.body.email;
    let password = req.body.password;
    model.findOne({
            email: email
        })
        .then(user => {
            if (!user) {
                console.log('wrong email address');
                req.flash('error', 'wrong email address');
                res.redirect('/users/login');
            } else {
                user.comparePassword(password)
                    .then(result => {
                        if (result) {
                            req.session.user = user._id;
                            req.flash('success', 'You have successfully logged in');
                            res.redirect('/users/profile');
                        } else {
                            req.flash('error', 'wrong password');
                            res.redirect('/users/login');
                        }
                    });
            }
        })
        .catch(err => next(err));
};

exports.profile = (req, res, next) => {
    let id = req.session.user;
    Promise.all([model.findById(id).populate('wishlist').populate({
            path: 'trades',
            populate: {
                path: 'trade offeredTrade'
            }
        }), Trade.find({
            owner: id
        })])
        .then(results => {
            const [user, trades] = results;
            res.render('./user/profile', {
                user,
                trades
            });
        })
        .catch(err => next(err));
};


exports.logout = (req, res, next) => {
    req.session.destroy(err => {
        if (err)
            return next(err);
        else
            res.redirect('/');
    });

};

exports.addOrRemoveWishlistItem = (req, res, next) => {
    let id = req.params.id;
    let userid = req.session.user;
    model.findById(userid)
        .then(user => {
            if (user.wishlist.includes(id)) {
                user.wishlist.pull(id)
                user.save()
                    .then(result => {
                        return res.redirect('back');
                    })
            } else {
                user.wishlist.push(id)
                user.save()
                    .then(result => {
                        req.flash('success', 'Trade has been successfully added to wishlist');
                        return res.redirect('/users/profile');
                    })
            }
        })
        .catch(err => next(err));
}

exports.showOfferableTrades = (req, res, next) => {
    let tradeId = req.params.id;
    let user = req.session.user;
    Trade.find({
            owner: user,
            status: 'Available'
        })
        .then(trades => {
            res.render('./user/offer', {
                trades,
                tradeId
            });
        })
        .catch(err => next(err));
}

exports.addOffer = (req, res, next) => {
    let userid = req.session.user;
    let tradeId = req.params.id;
    let offeredId = req.body.offeredId;
    Trade.findById(tradeId)
        .then(trade => {
            if (trade) {
                Promise.all([model.findById(userid), model.findById(trade.owner), Trade.findByIdAndUpdate(tradeId, {
                        status: 'Offer Pending'
                    }), Trade.findByIdAndUpdate(offeredId, {
                        status: 'Offer Pending'
                    })])
                    .then(results => {
                        const [user, owner, tradeIdUp, offeredIdUp] = results;
                        user.trades.push({
                            trade: tradeId,
                            offeredTrade: offeredId,
                            isOwner: false,
                        });
                        owner.trades.push({
                            trade: tradeId,
                            offeredTrade: offeredId,
                            isOwner: true,
                        });
                        Promise.all([user.save(), owner.save()])
                            .then(result => {
                                req.flash('success', 'Offer has been successfully made');
                                return res.redirect('/users/profile');
                            })
                    })
            } else {
                handle404Error(id, next);
            }
        })
        .catch(err => next(err));
}

exports.deleteOffer = (req, res, next) => {
    let id = req.params.id;
    model.findOne({
            'trades._id': id
        }).populate({
            path: 'trades',
            populate: {
                path: 'trade offeredTrade'
            }
        })
        .then(user => {
            tradeOwner = user.trades[0].trade.owner;
            offeredOwner = user.trades[0].offeredTrade.owner;
            tradeId = user.trades[0].trade._id;
            offeredId = user.trades[0].offeredTrade._id;
            Promise.all([model.findByIdAndUpdate(tradeOwner, {
                $pull: {
                    trades: {
                        trade: tradeId,
                        offeredTrade: offeredId
                    }
                }
            }), model.findByIdAndUpdate(offeredOwner, {
                $pull: {
                    trades: {
                        trade: tradeId,
                        offeredTrade: offeredId
                    }
                }
            }), Trade.findByIdAndUpdate(tradeId, {
                status: 'Available'
            }), Trade.findByIdAndUpdate(offeredId, {
                status: 'Available'
            })])
            .then(results => {
                return res.redirect('back');
            })
        })
        .catch(err => next(err));
}


exports.acceptOffer = (req, res, next) => {
    let id = req.params.id;
    model.findOne({
            'trades._id': id
        }).populate({
            path: 'trades',
            populate: {
                path: 'trade offeredTrade'
            }
        })
        .then(user => {
            tradeOwner = user.trades[0].trade.owner;
            offeredOwner = user.trades[0].offeredTrade.owner;
            tradeId = user.trades[0].trade._id;
            offeredId = user.trades[0].offeredTrade._id;
            Promise.all([model.findByIdAndUpdate(tradeOwner, {
                $pull: {
                    trades: {
                        trade: tradeId,
                        offeredTrade: offeredId
                    }
                }
            }), model.findByIdAndUpdate(offeredOwner, {
                $pull: {
                    trades: {
                        trade: tradeId,
                        offeredTrade: offeredId
                    }
                }
            }), Trade.findByIdAndUpdate(tradeId, {
                status: 'Traded', owner: offeredOwner
            }), Trade.findByIdAndUpdate(offeredId, {
                status: 'Traded', owner: tradeOwner
            })])
            .then(results => {
                return res.redirect('back');
            })
        })
        .catch(err => next(err));
}
