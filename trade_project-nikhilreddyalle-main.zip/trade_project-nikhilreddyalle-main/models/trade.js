const mongoose = require('mongoose');

const Schema = mongoose.Schema;

const tradeSchema = new Schema({
    brand: {type: String, required: [true, 'brand is required']},
    model: {type: String, required: [true, 'model is required']},
    category: {type: String, required: [true, 'Category is required']},
    color: {type: String,  required: [true, 'color is required']},
    varient: {type: String,  required: [true, 'varient is required']},
    image: {type: String, required: [true, 'Image URL is required']},
    status: {type: String,  required: [true, 'Status is required']},
    condition:{type: String, required: [true, 'Condition is required']},
    owner: {type: Schema.Types.ObjectId, ref:'User'}
});

module.exports = mongoose.model('Trade', tradeSchema);

